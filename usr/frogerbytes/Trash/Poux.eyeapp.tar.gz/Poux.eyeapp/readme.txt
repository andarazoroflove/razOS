Ported to eyeOS by Robbie Ferguson - www.eyeOS.ca

Poux v.1.0 - May 7, 2006
------------------------
A flash game where you destroy as many gems as you can by
clicking on colored gems that are surrounded by their own
colors.  An excellent puzzle game.

Poux uses Flash, and therefore an installed copy of the
Flash plugin is required for your browser before Poux will
run.


Known Bugs:
- None known.